/*
 * run_cmd.h				           (c) 2001 Staf Wagemakers
 */
#include "configfile.h"
int run_cmd(FILE *config_file,char *section,char *directive,char *vars[][2]);
