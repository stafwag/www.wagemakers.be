/*
 * out_of_memory.h				(c) 2001 Staf Wagemakers
 */

#include "xmalloc.h"
#include "write_log.h"
void out_of_memory(void);
