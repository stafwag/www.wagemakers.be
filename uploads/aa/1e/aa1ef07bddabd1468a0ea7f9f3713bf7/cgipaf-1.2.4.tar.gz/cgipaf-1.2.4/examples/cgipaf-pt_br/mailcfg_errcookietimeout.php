<?
include "./mailcfg_top.php";
?>
<font color="#FF0000">
<H1>Cookie timeout <? echo $cookie_timeout ?> (s) exceeded<BR>
Please relogin</H1>
</font>
<?
include "./mailcfg_login.php";
?>
