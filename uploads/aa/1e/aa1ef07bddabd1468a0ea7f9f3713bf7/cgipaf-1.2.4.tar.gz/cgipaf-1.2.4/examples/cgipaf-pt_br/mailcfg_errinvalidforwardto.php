<?
include "./mailcfg_top.php";
?>
<font color="#ff0000">
<h1>Forward inv�lido para endere�o de e-mail</h1>
</font>
<?
include "./mailcfg_form.php";
?>
