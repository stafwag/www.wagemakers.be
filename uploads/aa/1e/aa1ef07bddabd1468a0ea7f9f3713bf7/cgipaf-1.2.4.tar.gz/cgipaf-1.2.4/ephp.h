/*
 * ephp.h                              (GPL)     2001 Staf Wagemakers
 *                                     email   : staf@patat.org
 *                                               http://staf.patat.org
 */
#include <string.h>
#include <stdio.h>
#include "xmalloc.h"
#include "xstring.h"
int print_phpfile (char * filename,char *values[][2]);
