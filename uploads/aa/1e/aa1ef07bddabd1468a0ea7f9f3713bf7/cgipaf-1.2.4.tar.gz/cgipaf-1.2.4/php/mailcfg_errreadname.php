<?
include "./mailcfg_top.php";
?>
<font color="#ff0000">
<h1>Can't read your loginname</h1>
</font>
</body>
</html>
