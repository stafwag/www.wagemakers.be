<?
include "./mailcfg_top.php";
?>
<h1>Change your mailbox settings</h1>
<?
include "./mailcfg_form.php";
?>
