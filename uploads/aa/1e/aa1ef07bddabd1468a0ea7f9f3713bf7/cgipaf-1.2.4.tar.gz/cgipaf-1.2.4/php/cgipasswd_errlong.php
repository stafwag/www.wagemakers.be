<?
include "cgipasswd_top.php"
?>
<p>
<h1><b><i><font color="#ff0000">Password too long...</font></i></b></h1>
<p>maxium length:<? echo $max_length ?></p>
<?
include "cgipasswd_login.php"
?>
