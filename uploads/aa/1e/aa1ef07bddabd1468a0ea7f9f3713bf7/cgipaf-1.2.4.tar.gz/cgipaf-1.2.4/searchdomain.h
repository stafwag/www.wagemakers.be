/*
 * searchdomain.h                                 (c) 2001 Staf Wagemakers
 */
#ifdef NEED_COMPAT_H
#include "compat.h"
#endif
#include "configfile.h"
int searchdomain(char *domainname,size_t len);
