<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Wachtwoord succesvol aangepast...</title>
</head>
<body text="#00000" bgcolor="#B0B0B0">
<center>
<h1><b><i>Wachtwoord successvol aangepast...</i></b></h1>
</center>
</body>
</html>
