<?
include "cgipasswd_top.php"
?>
<?
include "cgipasswd_login.php"
?>
