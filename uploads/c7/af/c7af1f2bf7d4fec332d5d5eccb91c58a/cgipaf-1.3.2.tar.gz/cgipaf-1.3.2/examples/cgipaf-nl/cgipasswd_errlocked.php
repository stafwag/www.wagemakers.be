<?
include "cgipasswd_top.php"
?>
<p>
<h1><b><font color="#ff0000"><i>Maximum aantal poginen overschreden (<? echo $max_invalid; ?>)
<br>U moet <? echo $invalid_wait; ?> seconden wachten.</i></font></b></h1>
<p>
<?
include "cgipasswd_login.php"
?>
