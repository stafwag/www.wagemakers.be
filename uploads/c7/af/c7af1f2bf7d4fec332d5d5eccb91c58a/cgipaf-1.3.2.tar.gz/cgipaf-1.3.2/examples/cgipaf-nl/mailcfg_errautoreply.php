<?
include "./mailcfg_top.php";
?>
<font color="#FF0000">
<h1>Kan het afwezigheidsbericht niet lezen!</h1>
</font>
<?
include "./mailcfg_form.php";
?>
