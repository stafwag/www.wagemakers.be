<?
include "./mailcfg_top.php";
?>
<h1>Bekijk uw e-mail instellingen</h1>
<?
include "./mailcfg_login.php";
?>
