<?
include "./mailcfg_top.php";
?>
<font color="#FF0000">
<h1>N�o foi poss�vel ler a auto-resposta</h1>
</font>
<?
include "./mailcfg_form.php";
?>
