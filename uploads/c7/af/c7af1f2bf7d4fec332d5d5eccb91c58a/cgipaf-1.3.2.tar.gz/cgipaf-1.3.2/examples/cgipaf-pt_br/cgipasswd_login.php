<p>
<table>
<tr>
<td>Usu�rio</td><td>:</td><td><input name=name size=12 value="<?echo $name ?>"></td>
</tr>
<tr>
<td>Senha Atual</td><td>:</td><td><input name=passwd type=password></td>
</tr>
<tr>
<td>Senha Nova</td><td>:</td><td><input name=newpass1 size="<? echo $max_length ?>" type=password></td>
</tr>
<tr>
<td>Redigite a Senha Nova </td><td>:</td><td><input name=newpass2 size="<? echo $max_length ?>" type=password></td>
</tr>
</table>
<p>
<input type=submit value="Alterar">
<input type=reset  value="Limpar">
</p>
</center>
</form>
</body>
</html>
