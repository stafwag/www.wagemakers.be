<?
include "./mailcfg_top.php";
?>
<h1><font color="#FF0000">Access denied</font></h1>
<?
include "./mailcfg_login.php";
?>
