<?
include "./mailcfg_top.php";
?>
<font color="#ff0000">
<h1>Invalid forward to email address</h1>
</font>
<?
include "./mailcfg_form.php";
?>
