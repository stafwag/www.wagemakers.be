<?
include "./mailcfg_top.php";
?>
<h1><font color="#ff0000">Can not read loginname</font></h1>
<?
include "./mailcfg_login.php";
?>
