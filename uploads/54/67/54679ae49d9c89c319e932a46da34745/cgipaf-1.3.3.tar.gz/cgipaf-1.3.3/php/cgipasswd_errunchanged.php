<?
include "cgipasswd_top.php"
?>
<p>
<h1><b><i><font color="#ff0000">Password unchanged</font></i></b></h1>
<?
include "cgipasswd_login.php"
?>
