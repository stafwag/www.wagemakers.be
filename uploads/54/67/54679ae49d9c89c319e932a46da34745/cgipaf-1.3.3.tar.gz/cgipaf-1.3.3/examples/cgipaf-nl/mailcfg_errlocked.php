<?
include "mailcfg_top.php"
?>
<P>
<h1><b><font color="#ff0000">Maximum number of tries exceeded (<? echo $max_invalid; ?>)
<br>You've to wait <? echo $invalid_wait; ?> seconds.</font></b></h1>
</p>
<?
include "mailcfg_login.php"
?>
