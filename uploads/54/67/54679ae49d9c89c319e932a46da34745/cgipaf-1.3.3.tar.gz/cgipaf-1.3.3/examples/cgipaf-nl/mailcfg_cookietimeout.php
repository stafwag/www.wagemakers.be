<?
include "./mailcfg_top.php";
?>
<font color="#FF0000">
<h1>Cookie timeout <? echo $cookie_timeout ?> (s) exceeded</h1>
</font>
<?
include "./mailcfg_form.php";
?>
