<?
include "./mailcfg_top.php";
?>
<font color="#FF0000">
<h1>ERROR: can't read forward configurarion</h1>
</font>
<?
include "./mailcfg_form.php";
?>
