<?
include "cgipasswd_top.php"
?>
<p>
<h1><b><font color="#FF0000"><i>Geen toegang...</i></font></b></h1>
<?
include "cgipasswd_login.php"
?>
