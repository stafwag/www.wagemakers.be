<?
include "./mailcfg_top.php";
?>
<h1>Configura��es de E-Mail atualizadas com sucesso</h1>
</body>
</html>
