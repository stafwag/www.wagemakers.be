<?
include "./mailcfg_top.php";
?>
<h1>View your mailbox settings</h1>
<?
include "./mailcfg_login.php";
?>
