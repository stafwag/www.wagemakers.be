<?
include "cgipasswd_top.php"
?>
<p>
<h1><b><font color="#ff0000"><i>Onjuist wachtwoord of onjuiste gebruikersnaam...</i></font></b></h1>
<?
include "cgipasswd_login.php"
?>
