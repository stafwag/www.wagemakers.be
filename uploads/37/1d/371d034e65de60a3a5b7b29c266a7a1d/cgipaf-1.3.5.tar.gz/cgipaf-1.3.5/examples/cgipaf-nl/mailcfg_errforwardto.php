<?
include "./mailcfg_top.php";
?>
<font color="#FF0000">
<h1>Aan wie doorsturen?</h1>
</font>
<?
include "./mailcfg_form.php";
?>
