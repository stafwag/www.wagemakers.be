#!/bin/sh


. `dirname $0`/../config.sh

update_passwords -n
