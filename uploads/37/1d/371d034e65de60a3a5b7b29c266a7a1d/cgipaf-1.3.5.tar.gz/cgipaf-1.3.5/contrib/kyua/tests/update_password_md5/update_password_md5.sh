#!/bin/sh


. `dirname $0`/../config.sh

requiredHashType="md5"

update_passwords -m
