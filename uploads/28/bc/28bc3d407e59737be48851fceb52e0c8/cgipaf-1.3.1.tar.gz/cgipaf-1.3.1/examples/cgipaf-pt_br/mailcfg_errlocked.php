<?
include "mailcfg_top.php"
?>
<P>
<h1><b><font color="#ff0000">N�mero m�ximo de tentativas excedido (<? echo $max_invalid; ?>)
<br>Voc� dever� aguardar <? echo $invalid_wait; ?> segundos.</font></b></h1>
</p>
<?
include "mailcfg_login.php"
?>
