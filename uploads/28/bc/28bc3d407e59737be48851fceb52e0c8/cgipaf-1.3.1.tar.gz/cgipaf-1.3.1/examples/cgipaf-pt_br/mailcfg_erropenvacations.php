<?
include "./mailcfg_top.php";
?>
<font color="#FF0000">
<h1>N�o foi poss�vel abrir seu  ~/vacations.txt<br>
Por favor, contacte a Administra��o de Rede</h1>
</font>
</body>
</html>
