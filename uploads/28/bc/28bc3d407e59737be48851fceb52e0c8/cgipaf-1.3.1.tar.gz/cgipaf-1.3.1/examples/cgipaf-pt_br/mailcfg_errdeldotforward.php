<?
include "./mailcfg_top.php";
?>
<font color="#FF0000">
<h1>N�o foi poss�vel remover seu ~/.forward<br>
Por favor, contacte a Administra��o de Rede</h1>
</font>
</body>
</html>
