<?
include "./mailcfg_top.php";
?>
<font color="#FF0000">
<h1>To update your mail configuration your browser<br>
need to support cookies...</h1>
</font>
<?
include "./mailcfg_form.php";
?>
