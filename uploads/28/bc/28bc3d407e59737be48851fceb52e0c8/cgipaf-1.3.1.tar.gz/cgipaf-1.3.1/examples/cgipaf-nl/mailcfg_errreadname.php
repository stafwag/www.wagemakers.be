<?
include "./mailcfg_top.php";
?>
<font color="#ff0000">
<h1>Kan uw inlognaam niet lezen</h1>
</font>
</body>
</html>
