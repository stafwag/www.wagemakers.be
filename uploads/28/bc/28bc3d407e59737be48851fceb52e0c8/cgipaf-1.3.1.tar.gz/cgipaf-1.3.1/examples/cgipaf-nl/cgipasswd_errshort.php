<?
include "cgipasswd_top.php"
?>
<p>
<h1><b><i><font color="#ff0000">Wachtwoord is te kort...</font></i></b></h1>
<p>minimale lengte: <? echo $min_length; ?></p>
<?
include "cgipasswd_login.php"
?>
