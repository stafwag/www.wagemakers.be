<?
include "./mailcfg_top.php";
?>
<h1>Uw e-mail configuratie is succesvol aangepast</h1>
<a href="javascript:window.close()">sluit dit venster</a>
</body>
</html>
