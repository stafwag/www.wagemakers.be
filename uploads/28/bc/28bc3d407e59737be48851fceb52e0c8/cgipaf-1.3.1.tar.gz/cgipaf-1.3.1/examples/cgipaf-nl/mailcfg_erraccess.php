<?
include "./mailcfg_top.php";
?>
<h1><font color="#FF0000">Toegang verboden</font></h1>
<?
include "./mailcfg_login.php";
?>
