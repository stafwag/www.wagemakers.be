<?
include "./mailcfg_top.php";
?>
<h1>Mail configuration updated successfully</h1>
</body>
</html>
