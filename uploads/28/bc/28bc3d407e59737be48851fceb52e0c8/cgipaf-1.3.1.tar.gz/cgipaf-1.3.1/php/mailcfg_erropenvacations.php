<?
include "./mailcfg_top.php";
?>
<font color="#FF0000">
<h1>Can't open your ~/vacations.txt<br>
Please contact the webmaster</h1>
</font>
</body>
</html>
