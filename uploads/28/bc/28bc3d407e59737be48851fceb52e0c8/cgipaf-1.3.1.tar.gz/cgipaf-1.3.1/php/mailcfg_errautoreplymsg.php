<?
include "./mailcfg_top.php";
?>
<font color="#FF0000">
<h1>Can't read autoreply message</h1>
</font>
<?
include "./mailcfg_form.php";
?>
