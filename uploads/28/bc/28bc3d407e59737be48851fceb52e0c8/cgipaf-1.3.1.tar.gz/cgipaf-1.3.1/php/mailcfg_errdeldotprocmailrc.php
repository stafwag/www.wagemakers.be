<?
include "./mailcfg_top.php";
?>
<font color="#FF0000">
<h1>Can't remove your ~/.procmailrc<br>
Please contact the webmaster</h1>
</font>
</body>
</html>
