<?
include "./mailcfg_top.php";
?>
<font color="#FF0000">
<h1>Can't remove your ~/.procmailrc<br>
Neem contact op met ProcoliX - 015-2190692</h1>
</font>
</body>
</html>
