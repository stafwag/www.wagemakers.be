<?
include "./mailcfg_top.php";
?>
<font color="#ff0000">
<h1>N�o foi poss�vel ler seu login</h1>
</font>
</body>
</html>
