<?
include "cgipasswd_top.php"
?>
<p>
<h1><b><font color="#ff0000"><? echo $pam_error; ?></font></b></h1>
<?
include "cgipasswd_login.php"
?>
