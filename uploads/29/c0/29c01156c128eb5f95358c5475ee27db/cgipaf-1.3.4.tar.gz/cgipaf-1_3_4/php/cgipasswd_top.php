<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>
Web passwd program.
</title>
</head>
<body text="#00000" bgcolor="#B0B0B0">
<form method=POST ACTION="/cgi-bin/passwd.cgi">
<center>
