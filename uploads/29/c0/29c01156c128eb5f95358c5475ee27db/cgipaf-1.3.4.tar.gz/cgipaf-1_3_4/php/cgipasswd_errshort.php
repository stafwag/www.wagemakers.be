<?
include "cgipasswd_top.php"
?>
<p>
<h1><b><i><font color="#ff0000">Password too short...</font></i></b></h1>
<p>minium length: <? echo $min_length; ?></p>
<?
include "cgipasswd_login.php"
?>
