<?
include "./mailcfg_top.php";
?>
<font color="#FF0000">
<h1>ERRO: n�o foi poss�vel ler a configura��o de forward</h1>
</font>
<?
include "./mailcfg_form.php";
?>
