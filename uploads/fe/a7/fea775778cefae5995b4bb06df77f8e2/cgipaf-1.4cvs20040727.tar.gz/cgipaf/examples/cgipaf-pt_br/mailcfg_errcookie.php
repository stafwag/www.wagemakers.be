<?
include "./mailcfg_top.php";
?>
<font color="#FF0000">
<h1>Para atualizar suas configura��es de mail,<br>
seu broser deve aceitar cookies...</h1>
</font>
<?
include "./mailcfg_form.php";
?>
