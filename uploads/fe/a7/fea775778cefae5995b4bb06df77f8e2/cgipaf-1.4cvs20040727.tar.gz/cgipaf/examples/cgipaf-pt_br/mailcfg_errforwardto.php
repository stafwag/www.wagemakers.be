<?
include "./mailcfg_top.php";
?>
<font color="#FF0000">
<h1>Encaminhar para quem ???</h1>
</font>
<?
include "./mailcfg_form.php";
?>
