<?
include "./mailcfg_top.php";
?>
<h1><font color="#ff0000">N�o foi poss�vel ler o login</font></h1>
<?
include "./mailcfg_login.php";
?>
