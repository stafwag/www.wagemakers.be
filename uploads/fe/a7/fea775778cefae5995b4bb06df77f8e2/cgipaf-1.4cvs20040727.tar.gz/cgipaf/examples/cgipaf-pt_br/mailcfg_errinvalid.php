<?
include "./mailcfg_top.php";
?>
<h1><font color="#FF0000">Usu�rio ou senha inv�lidos</font></h1>
<?
include "./mailcfg_login.php";
?>
