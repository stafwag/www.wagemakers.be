<?
include "./mailcfg_top.php";
?>
<h1><font color="#ff0000">Kan uw inlognaam niet lezen.</font></h1>
<?
include "./mailcfg_login.php";
?>
