<?
include "cgipasswd_top.php"
?>
<p>
<h1><b><font color="#ff0000"><i>Geen juist wachtwoord:
<br><? echo $bad_password; ?></i></font></b></h1>
<p>
<?
include "cgipasswd_login.php"
?>
