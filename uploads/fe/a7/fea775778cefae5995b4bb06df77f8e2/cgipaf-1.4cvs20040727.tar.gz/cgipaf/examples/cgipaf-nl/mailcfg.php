<?
include "./mailcfg_top.php";
?>
<h1>Verander uw e-mail instellingen</h1>
<?
include "./mailcfg_form.php";
?>
