<?
include "./admin_top.php"
?>
<h1>Mailcfg admin</h1>
<?
include "./mailadmin_login.php";
?>
