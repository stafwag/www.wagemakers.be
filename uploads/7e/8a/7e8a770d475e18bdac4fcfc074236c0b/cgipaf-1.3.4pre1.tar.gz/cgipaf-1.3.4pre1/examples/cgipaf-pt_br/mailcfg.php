<?
include "./mailcfg_top.php";
?>
<h1>Altera��o das configura��es de e-mail</h1>
<?
include "./mailcfg_form.php";
?>
