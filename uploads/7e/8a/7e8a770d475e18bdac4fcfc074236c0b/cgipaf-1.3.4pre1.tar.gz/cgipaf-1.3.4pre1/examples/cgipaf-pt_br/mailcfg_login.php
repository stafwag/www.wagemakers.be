<hr>
<p>
<form action="/cgi-bin/viewmailcfg.cgi" method="post">
<table width="80%">
<tr>
<td bgcolor="#b0b0b0" width="20%">Usu�rio:</td>
<td align="left"><input name="name" type="text" size="30" maxlength="30" value="<? echo $name ?>"></td>
<td width="20%">senha :</td>
<td><input name="passwd" type="password" size="20" maxlength="16"></td>
</tr>
</table>
<hr>
<center>
<table>
<tr>
<td>
<input type="reset" value="Limpar">
</td>
<td>
<input type="submit" value="Enviar">
</td>
</tr>
</table>
</center>
</form>
</body>
