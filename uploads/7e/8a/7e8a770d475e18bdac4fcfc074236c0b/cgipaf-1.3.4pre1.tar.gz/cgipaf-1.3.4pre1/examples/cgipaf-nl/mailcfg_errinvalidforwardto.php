<?
include "./mailcfg_top.php";
?>
<font color="#ff0000">
<h1>Onjuist e-mail adres om aan door te sturen</h1>
</font>
<?
include "./mailcfg_form.php";
?>
