<hr>
<p>
<form action="/viewmailcfg.cgi" method="post">
<table>
<tr>
<td bgcolor="#b0b0b0">Inlognaam:</td>
<td align="center"><input name="name" type="text" size="10" maxlength="15" value="<? echo $name ?>"></td>
</tr>
<tr>
<td>Wachtwoord :</td>
<td><input name="passwd" type="password" size="8" maxlength="16"></td>
</tr>
</table>
<hr>
<center>
<table>
<tr>
<td>
<input type="reset" value="Leegmaken">
</td>
<td>
<input type="submit" value="Doorgaan">
</td>
</tr>
</table>
</center>
</form>
</body>
